document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('[data-nav-toggle]');
  const nav = document.querySelector('[data-header-nav]');

  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(isOpen));
    });
  }
});
